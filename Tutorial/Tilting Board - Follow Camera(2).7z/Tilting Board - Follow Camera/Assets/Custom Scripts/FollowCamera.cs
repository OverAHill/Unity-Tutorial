using UnityEngine;
using System.Collections;

public class FollowCamera : MonoBehaviour 
{
	public GameObject followTarget;
	
	// Update is called once per frame
	void Update ()
	{
		transform.position = new Vector3(followTarget.transform.position.x, followTarget.transform.position.y + 100, followTarget.transform.position.z);
	}
}
