using UnityEngine;
using System.Collections;

public class Tilt : MonoBehaviour 
{
	float smooth = 1.5f;
	float tiltAngle = 30.0f;

	// Use this for initialization
	void Start ()
	{}
	
	// Update is called once per frame
	void Update ()
	{
		//check if the user is pressing left or right, up or down on the keyboard
		//by default Unity assigns the "a" and "d" key as well as the left and right arrow keys to the horizontal axis and the "w" and "s" key as well as the up and down arrows keys to the vertical axis.
		float tiltAroundX = Input.GetAxis("Horizontal") * tiltAngle;
		float tiltAroundZ = Input.GetAxis("Vertical") * tiltAngle;
		
		Quaternion target = Quaternion.Euler(tiltAroundX, 0, tiltAroundZ);
		
		transform.rotation = Quaternion.Slerp(transform.rotation, target, Time.deltaTime * smooth);	
	}
}
