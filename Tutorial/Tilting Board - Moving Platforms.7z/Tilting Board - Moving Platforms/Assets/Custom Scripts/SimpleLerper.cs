using UnityEngine;
using System.Collections;

public class SimpleLerper : MonoBehaviour 
{
	public Transform pointOne;
	public Transform pointTwo;
	public float moveTime = 3.0f;
	private float startTime;
	
	void Start()
	{
		startTime = Time.time;
	}
	
	void Update()
	{                            
		float fracTime = (Time.time - startTime ) / moveTime;
					
		// Debug.Log("Frac time: " + fracTime);
		
		transform.position = Vector3.Lerp(pointOne.position, pointTwo.position, fracTime); 

		// reached destination point
		if(fracTime >= 1.0f)
		{
			startTime = Time.time;		// reset start time
			
			// switch points around
			Transform temp = pointOne;
			pointOne = pointTwo;
			pointTwo = temp;
		}			
	}
}
