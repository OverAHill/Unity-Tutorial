using UnityEngine;

public class SimpleMover : MonoBehaviour 
{
	public Transform pointOne;
	public Transform pointTwo;
	public float moveTime = 1;
	private float moveSpeed;

	private Transform moveToPoint;
    private Rigidbody myRigidbody;

    void Awake()
    {
        myRigidbody = GetComponent<Rigidbody>();
    }

    void Start()
	{
		if (moveTime == 0.0f)
		{
			moveTime = 1;
		}

		moveToPoint = pointTwo;
		moveSpeed = Vector3.Distance(pointOne.position, pointTwo.position) / moveTime;
	}
	
	void FixedUpdate()
	{      
		Vector3 distanceRemaining = moveToPoint.position - transform.position;
		Vector3 maximumDistance = distanceRemaining.normalized * moveSpeed * Time.deltaTime;
		
		if (maximumDistance.magnitude > distanceRemaining.magnitude)
		{
			maximumDistance = distanceRemaining;
			
			// Debug.Log("Swapping destination");
			
			// swap points
			if (moveToPoint == pointOne)
			{
				moveToPoint = pointTwo;
			}
			else
			{	
				moveToPoint = pointOne;
			}			
		}

        myRigidbody.MovePosition(transform.position + maximumDistance); 
	}
}
