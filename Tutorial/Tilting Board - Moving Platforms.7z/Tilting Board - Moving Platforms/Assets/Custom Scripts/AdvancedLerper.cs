using UnityEngine;
using System.Collections;

public class AdvancedLerper : MonoBehaviour 
{
	public Transform pointOne;
	public Transform pointTwo;
	public float moveTime = 3.0f;
 
	IEnumerator Start ()
	{   	
		while (true)
		{			
			yield return StartCoroutine(MoveObject(transform, pointOne, pointTwo, moveTime));
			yield return StartCoroutine(MoveObject(transform, pointTwo, pointOne, moveTime));
		}
	}
 
	IEnumerator MoveObject (Transform thisTransform, Transform startPos, Transform endPos, float time)
	{
		float i = 0.0f;
		float rate = 1.0f / time;

		while (i < 1.0f)
		{
			i += Time.deltaTime * rate;
					
			thisTransform.position = Vector3.Lerp(startPos.position, endPos.position, i);
			yield return null; 
		}
	}
}
