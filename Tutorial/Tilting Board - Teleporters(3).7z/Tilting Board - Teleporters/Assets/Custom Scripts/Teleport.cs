using UnityEngine;
using System.Collections;

public class Teleport : MonoBehaviour 
{
	public GameObject exitPoint;
	
	void OnTriggerEnter(Collider other)
	{
		other.transform.position = exitPoint.transform.position;
	}
}
