using UnityEngine;
using System.Collections;

public class PickUp : MonoBehaviour 
{	
	public int points = 10;
    public BallCharacter ballCharacter;

    void Awake()
    {
        GameObject ball = GameObject.Find("Ball");

        if (ball != null)
        {
            ballCharacter = ball.GetComponent<BallCharacter>();
        }
    }

	void OnTriggerEnter(Collider other)	
	{		
		if (other.gameObject.tag == "Player")
		{
            // we know it is the ball that has hit the pickup here and not anything else because of the tag on the Ball GameObject in the scene
            ballCharacter.score += points;

			// this deletes the pickup GameObject from your scene after the frame is drawn	
			Destroy(gameObject);		
		}	
	}
}
